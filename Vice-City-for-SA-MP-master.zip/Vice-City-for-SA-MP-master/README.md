# Vice-City-for-SA-MP
This is a conversion of Vice City from GTA United 1.2 for SA-MP 0.3DL

## Download Models
[http://sharemods.com/kkzd15mvm9g4/vicecity_models_v2_by_niko.zip.html](http://sharemods.com/kkzd15mvm9g4/vicecity_models_v2_by_niko.zip.html)

## Requeriments
[Streamer](http://forum.sa-mp.com/showthread.php?t=102865) by Incognito

[ZCMD](http://forum.sa-mp.com/showthread.php?t=91354) by Zeex (OPTIONAL)

[foreach](http://forum.sa-mp.com/showthread.php?t=570868) (optional) by Y_Less (OPTIONAL)

## Installation
1. Download the vicecity.pwn and put in your filterscript folder, and compile with 0.3DL includes;
2. Download the models and put "vc4samp" in models folders.
3. Put vicecity in filterscript line in server.cfg or use /rcon loadfs vicecity
4. (Optional) create folder call "vicecity" in main folder of you server, and put file textures.inc.
4. Use command /gotovc for enjoy city.

## Important Read
This projects stay unfinished because I don't have time, and in live time, i making other gamemode in priority. 
