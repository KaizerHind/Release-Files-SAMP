kdff by Kalcor (SA-MP Team)
---------------------------------------

kdff is a collision generator, and model viewer, for GTA San Andreas models. It can generate
various types of GTA col (version 3) collision files given a dff model.

The generated collision can be edited externally and then attached to the dff.

Instructions:

Extract the files to their own folder and then run either kdffgui.exe or kdff.exe (console application)
depending on your needs.

Files:

kdffgui.exe : The main GUI program.
kdff.exe : The console application. Run this on the command line with no arguments for example usage.
kdff.dll : A dll required by kdffgui.exe, containing the col generation code.

---------------------------------------

v0.1.1d 11/2017 - (fixed) A corrupt dff would be generated when attaching .col to a .dff containing lights.

v0.1.1c 11/2017 - Adds -p mode to kdff.exe console app

v0.1.1(a/b) 11/2017 - First release
